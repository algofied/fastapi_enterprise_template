# src/app/infrastructure/db/base.py

from app.infrastructure.db.base_class import Base

# import the entire models package (triggers the __init__.py above)
import app.infrastructure.db.models
