from app.auth.ldap_client import ldap_bind
auth = ldap_bind("31962590","MYhpcl117**")
print(auth)